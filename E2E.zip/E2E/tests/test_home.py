from pages.Home.home_page import homepage
from locator.homepage_form_locators import HomepageLocators


def test_login(driver):
    # Create a new instance of the Home page
    home_page = homepage(driver)
    # Load the Home page
    home_page.load_URL()
    # Verify that home page is visible successfully
    assert "Amazon.com. Spend less. Smile more." in driver.title
    home_page.set_value_into_element(HomepageLocators.search_input_locator, 'bag')
    home_page.click_on_element(HomepageLocators.search_button_locator)

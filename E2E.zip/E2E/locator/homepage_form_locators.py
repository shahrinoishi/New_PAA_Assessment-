from selenium.webdriver.common.by import By


class HomepageLocators:
    search_dropdown_locator = "(//label[contains(text(), 'Select the department you want to search in')]/..//select)"
    search_id = (By.ID,'searchDropdownDescription')
    search_input_locator = (By.XPATH, "//input[@id='twotabsearchtextbox']")
    search_button_locator = (By.ID, 'nav-search-submit-button')


